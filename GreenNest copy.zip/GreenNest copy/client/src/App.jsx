
import { useState, useEffect, useCallback } from 'react'
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts'
import './App.css'

const API = 'http://localhost:5000/api'
const today = () => new Date().toLocaleDateString('en-CA')

const emptyPlant = {
  name: '',
  type: '',
  location: '',
  watering: 'Weekly',
  sunlight: 'Indirect sunlight',
  emoji: '🪴',
  status: 'Healthy',
}

const emptyTask = {
  title: '',
  plant: '',
  type: 'Watering',
  date: today(),
}

const emptyGrowth = {
  plant: '',
  height: '',
  date: today(),
  notes: '',
}

const emptyHealth = {
  plant: '',
  date: today(),
  status: 'Healthy',
  observation: '',
  treatment: '',
}

async function apiRequest(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  })

  const data = await response.json().catch(() => ({}))

  if (!response.ok) {
    throw new Error(data.message || `Request failed: ${response.status}`)
  }

  return data
}

function normalize(items) {
  return items.map((item) => ({ ...item, id: item._id }))
}

function App() {
  const [activePage, setActivePage] = useState('Dashboard')
  const [plants, setPlants] = useState([])
  const [tasks, setTasks] = useState([])
  const [growthRecords, setGrowthRecords] = useState([])
  const [healthRecords, setHealthRecords] = useState([])

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState('All')
  const [healthFilter, setHealthFilter] = useState('All')

  const [showPlantForm, setShowPlantForm] = useState(false)
  const [editingPlantId, setEditingPlantId] = useState(null)
  const [plantForm, setPlantForm] = useState({ ...emptyPlant })

  const [showTaskForm, setShowTaskForm] = useState(false)
  const [taskForm, setTaskForm] = useState({ ...emptyTask })

  const [showGrowthForm, setShowGrowthForm] = useState(false)
  const [growthForm, setGrowthForm] = useState({ ...emptyGrowth })

  const [showHealthForm, setShowHealthForm] = useState(false)
  const [healthForm, setHealthForm] = useState({ ...emptyHealth })

  const loadAll = useCallback(async () => {
    setLoading(true)
    setError('')

    try {
      const [plantData, taskData, growthData, healthData] =
        await Promise.all([
          apiRequest('/plants'),
          apiRequest('/tasks'),
          apiRequest('/growth'),
          apiRequest('/health'),
        ])

      setPlants(normalize(plantData))
      setTasks(normalize(taskData))
      setGrowthRecords(normalize(growthData))
      setHealthRecords(normalize(healthData))
    } catch (err) {
      setError(
        `${err.message}. Check that the backend is running on port 5000.`
      )
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadAll()
  }, [loadAll])

  function notify(message) {
    setNotice(message)
    window.setTimeout(() => setNotice(''), 3000)
  }

  function openPage(page) {
    setActivePage(page)
  }

  // PLANTS: ADD AND EDIT
  function openAddPlant() {
    setEditingPlantId(null)
    setPlantForm({ ...emptyPlant })
    setShowPlantForm(true)
  }

  function openEditPlant(plant) {
    setEditingPlantId(plant.id)
    setPlantForm({
      name: plant.name || '',
      type: plant.type || '',
      location: plant.location || '',
      watering: plant.watering || 'Weekly',
      sunlight: plant.sunlight || 'Indirect sunlight',
      emoji: plant.emoji || '🪴',
      status: plant.status || 'Healthy',
    })
    setShowPlantForm(true)
  }

  async function savePlant(event) {
    event.preventDefault()
    setError('')

    try {
      const editing = Boolean(editingPlantId)
      const data = await apiRequest(
        editing ? `/plants/${editingPlantId}` : '/plants',
        {
          method: editing ? 'PUT' : 'POST',
          body: JSON.stringify(plantForm),
        }
      )

      if (editing) {
        setPlants((previous) =>
          previous.map((plant) =>
            plant.id === editingPlantId
              ? { ...data, id: data._id }
              : plant
          )
        )
        notify('Plant details updated!')
      } else {
        setPlants((previous) => [
          ...previous,
          { ...data, id: data._id },
        ])
        notify('Plant added successfully!')
      }

      setShowPlantForm(false)
    } catch (err) {
      setError(err.message)
    }
  }

  async function deletePlant(id) {
    const plant = plants.find((item) => item.id === id)
    if (!plant || !window.confirm(`Delete ${plant.name} and its related records?`)) {
      return
    }

    try {
      await apiRequest(`/plants/${id}`, { method: 'DELETE' })
      setPlants((previous) => previous.filter((item) => item.id !== id))
      await loadAll()
      notify('Plant deleted.')
    } catch (err) {
      setError(err.message)
    }
  }

  // CARE TASKS: SAVE AND COMPLETE
  async function addTask(event) {
    event.preventDefault()
    setError('')

    try {
      const data = await apiRequest('/tasks', {
        method: 'POST',
        body: JSON.stringify({ ...taskForm, completed: false }),
      })

      setTasks((previous) => [
        { ...data, id: data._id },
        ...previous,
      ])
      setShowTaskForm(false)
      setTaskForm({ ...emptyTask, plant: plants[0]?.name || '' })
      notify('Care task saved to MongoDB!')
    } catch (err) {
      setError(err.message)
    }
  }

  async function toggleTask(task) {
    try {
      const data = await apiRequest(`/tasks/${task.id}`, {
        method: 'PUT',
        body: JSON.stringify({ completed: !task.completed }),
      })

      setTasks((previous) =>
        previous.map((item) =>
          item.id === task.id ? { ...data, id: data._id } : item
        )
      )
    } catch (err) {
      setError(err.message)
    }
  }

  async function deleteTask(id) {
    try {
      await apiRequest(`/tasks/${id}`, { method: 'DELETE' })
      setTasks((previous) => previous.filter((item) => item.id !== id))
      notify('Care task deleted.')
    } catch (err) {
      setError(err.message)
    }
  }

  // GROWTH RECORDS: SAVE AND DELETE
  async function addGrowthRecord(event) {
    event.preventDefault()
    const height = Number(growthForm.height)

    if (!Number.isFinite(height) || height <= 0) {
      setError('Enter a valid plant height greater than zero.')
      return
    }

    try {
      const data = await apiRequest('/growth', {
        method: 'POST',
        body: JSON.stringify({ ...growthForm, height }),
      })

      setGrowthRecords((previous) => [
        ...previous,
        { ...data, id: data._id },
      ])
      setShowGrowthForm(false)
      setGrowthForm({ ...emptyGrowth })
      notify('Growth record saved to MongoDB!')
    } catch (err) {
      setError(err.message)
    }
  }

  async function deleteGrowthRecord(id) {
    try {
      await apiRequest(`/growth/${id}`, { method: 'DELETE' })
      setGrowthRecords((previous) =>
        previous.filter((record) => record.id !== id)
      )
      notify('Growth record deleted.')
    } catch (err) {
      setError(err.message)
    }
  }

  // HEALTH JOURNAL: SAVE AND DELETE
  async function addHealthRecord(event) {
    event.preventDefault()

    try {
      const data = await apiRequest('/health', {
        method: 'POST',
        body: JSON.stringify(healthForm),
      })

      setHealthRecords((previous) => [
        { ...data, id: data._id },
        ...previous,
      ])

      setPlants((previous) =>
        previous.map((plant) =>
          plant.name === healthForm.plant
            ? { ...plant, status: healthForm.status }
            : plant
        )
      )

      setShowHealthForm(false)
      setHealthForm({ ...emptyHealth })
      notify('Health observation saved to MongoDB!')
    } catch (err) {
      setError(err.message)
    }
  }

  async function deleteHealthRecord(id) {
    try {
      await apiRequest(`/health/${id}`, { method: 'DELETE' })
      setHealthRecords((previous) =>
        previous.filter((record) => record.id !== id)
      )
      notify('Health observation deleted.')
    } catch (err) {
      setError(err.message)
    }
  }

  // FILTERS AND DASHBOARD COUNTS
  const filteredPlants = plants.filter((plant) => {
    const term = search.toLowerCase()
    const matchesSearch = [
      plant.name,
      plant.type,
      plant.location,
    ].some((value) => (value || '').toLowerCase().includes(term))

    const matchesType =
      typeFilter === 'All' || plant.type === typeFilter

    const matchesHealth =
      healthFilter === 'All' || plant.status === healthFilter

    return matchesSearch && matchesType && matchesHealth
  })

  const pendingTasks = tasks.filter((task) => !task.completed)
  const completedTasks = tasks.filter((task) => task.completed)
  const healthyPlants = plants.filter(
    (plant) => plant.status === 'Healthy'
  )
  const plantsTracked = new Set(
    growthRecords.map((record) => record.plant)
  ).size

  const overdueTasks = pendingTasks.filter((task) => task.date < today())
  const dueTodayTasks = pendingTasks.filter(
    (task) => task.date === today()
  )

  // PLANT CARDS
  function renderPlantCards(list = filteredPlants) {
    if (!list.length) {
      return (
        <div className="empty-state">
          <span>🪴</span>
          <h3>No plants found</h3>
          <p>Add a plant or change your search filters.</p>
        </div>
      )
    }

    return (
      <div className="plant-grid">
        {list.map((plant) => (
          <div className="plant-card" key={plant.id}>
            <div className="plant-card-top">
              <div className="plant-emoji">{plant.emoji || '🪴'}</div>
              <div>
                <button
                  className="text-btn"
                  onClick={() => openEditPlant(plant)}
                  title="Edit plant"
                >
                  ✏️ Edit
                </button>
                <button
                  className="delete-btn"
                  onClick={() => deletePlant(plant.id)}
                  title="Delete plant"
                >
                  🗑️
                </button>
              </div>
            </div>

            <h3>{plant.name}</h3>
            <p className="plant-type">{plant.type}</p>

            <div className="plant-details">
              <p>📍 {plant.location}</p>
              <p>💧 {plant.watering}</p>
              <p>☀️ {plant.sunlight}</p>
            </div>

            <div className="plant-card-bottom">
              <span
                className={`health-status ${
                  plant.status === 'Healthy'
                    ? 'status-healthy'
                    : plant.status === 'Needs Attention'
                      ? 'status-attention'
                      : 'status-treatment'
                }`}
              >
                {plant.status || 'Healthy'}
              </span>
              <button
                className="text-btn"
                onClick={() => {
                  setGrowthForm({
                    ...emptyGrowth,
                    plant: plant.name,
                  })
                  setShowGrowthForm(true)
                }}
              >
                + Record Growth
              </button>
            </div>
          </div>
        ))}
      </div>
    )
  }

  // TASK LIST WITH DUE / OVERDUE REMINDERS
  function renderTaskRows(list = tasks) {
    if (!list.length) {
      return (
        <div className="empty-state">
          <span>🗓️</span>
          <h3>No care tasks yet</h3>
          <p>Add a task to plan your plant care.</p>
        </div>
      )
    }

    return (
      <div className="task-list">
        {list.map((task) => {
          const overdue = !task.completed && task.date < today()
          const dueToday = !task.completed && task.date === today()

          return (
            <div
              className={`task-row ${task.completed ? 'task-completed' : ''}`}
              key={task.id}
            >
              <button
                className={`task-checkbox ${task.completed ? 'checked' : ''}`}
                onClick={() => toggleTask(task)}
                title="Mark complete or pending"
              >
                {task.completed ? '✓' : ''}
              </button>

              <div className="task-info">
                <h4>{task.title}</h4>
                <p>{task.plant} · {task.type}</p>
                {overdue && <strong style={{ color: '#d93025' }}>⚠ Overdue</strong>}
                {dueToday && <strong style={{ color: '#b7791f' }}>🔔 Due today</strong>}
              </div>

              <div className="task-date">{task.date}</div>

              <span
                className={`task-status ${
                  task.completed ? 'status-completed' : 'status-pending'
                }`}
              >
                {task.completed ? 'Completed' : 'Pending'}
              </span>

              <button
                className="delete-btn"
                onClick={() => deleteTask(task.id)}
                title="Delete task"
              >
                🗑️
              </button>
            </div>
          )
        })}
      </div>
    )
  }

  // DASHBOARD
  function renderDashboard() {
    return (
      <>
        <div className="welcome-banner">
          <div className="welcome-banner-content">
            <span className="eyebrow">YOUR PERSONAL GARDEN</span>
            <h2>Grow a greener, happier home 🌿</h2>
            <p>Keep your plants healthy with simple care routines and growth tracking.</p>
            <button className="banner-btn" onClick={() => openPage('My Plants')}>
              Explore My Plants →
            </button>
          </div>
          <div className="welcome-banner-emoji">🪴</div>
        </div>

        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-icon green-icon">🪴</div>
            <div><span>Total Plants</span><h3>{plants.length}</h3><p>Plants in your garden</p></div>
          </div>
          <div className="stat-card">
            <div className="stat-icon orange-icon">🗓️</div>
            <div><span>Pending Tasks</span><h3>{pendingTasks.length}</h3><p>Tasks to complete</p></div>
          </div>
          <div className="stat-card">
            <div className="stat-icon purple-icon">📈</div>
            <div><span>Growth Records</span><h3>{growthRecords.length}</h3><p>Measurements saved</p></div>
          </div>
          <div className="stat-card">
            <div className="stat-icon blue-icon">💚</div>
            <div><span>Healthy Plants</span><h3>{healthyPlants.length}</h3><p>Plants marked healthy</p></div>
          </div>
        </div>

        {(overdueTasks.length > 0 || dueTodayTasks.length > 0) && (
          <section className="panel">
            <h2>🔔 Watering & Care Reminders</h2>
            {overdueTasks.length > 0 && (
              <p style={{ color: '#d93025' }}>
                {overdueTasks.length} overdue task(s) need attention.
              </p>
            )}
            {dueTodayTasks.length > 0 && (
              <p style={{ color: '#b7791f' }}>
                {dueTodayTasks.length} task(s) are due today.
              </p>
            )}
            {renderTaskRows([...overdueTasks, ...dueTodayTasks])}
          </section>
        )}

        <div className="dashboard-grid">
          <section className="panel">
            <div className="section-heading">
              <div><h2>My Plants</h2><p>Your growing collection</p></div>
              <button className="text-btn" onClick={() => openPage('My Plants')}>View All →</button>
            </div>
            {renderPlantCards(plants.slice(0, 4))}
          </section>

          <section className="panel">
            <div className="section-heading">
              <div><h2>Care Schedule</h2><p>Keep your plants happy</p></div>
              <button className="text-btn" onClick={() => openPage('Care Scheduler')}>View All →</button>
            </div>
            {renderTaskRows(pendingTasks.slice(0, 4))}
            <button
              className="primary-btn full-width-btn"
              onClick={() => {
                setTaskForm({ ...emptyTask, plant: plants[0]?.name || '' })
                setShowTaskForm(true)
              }}
            >
              + Add Care Task
            </button>
          </section>
        </div>

        <section className="panel">
          <div className="section-heading">
            <div><h2>Growth Analytics</h2><p>Follow your plants' growth journey.</p></div>
            <button className="text-btn" onClick={() => openPage('Growth Analytics')}>View Analytics →</button>
          </div>
          {growthRecords.length === 0
            ? <div className="empty-state"><span>📈</span><h3>Your growth story starts here</h3><p>Add growth records to track plant development.</p></div>
            : <p>{growthRecords.length} growth records saved in MongoDB.</p>}
        </section>
      </>
    )
  }

  function renderMyPlants() {
    const types = [...new Set(plants.map((plant) => plant.type).filter(Boolean))]

    return (
      <section className="panel page-panel">
        <div className="section-heading">
          <div><span className="eyebrow">YOUR GARDEN</span><h2>My Plants</h2><p>Manage your plant collection.</p></div>
          <button className="primary-btn" onClick={openAddPlant}>+ Add Plant</button>
        </div>

        <div className="search-container">
          <span>🔍</span>
          <input
            placeholder="Search by name, type, or location..."
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </div>

        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', margin: '12px 0 20px' }}>
          <label>
            Plant type{' '}
            <select value={typeFilter} onChange={(event) => setTypeFilter(event.target.value)}>
              <option value="All">All types</option>
              {types.map((type) => <option key={type}>{type}</option>)}
            </select>
          </label>

          <label>
            Health status{' '}
            <select value={healthFilter} onChange={(event) => setHealthFilter(event.target.value)}>
              <option value="All">All statuses</option>
              <option>Healthy</option>
              <option>Needs Attention</option>
              <option>Under Treatment</option>
            </select>
          </label>
        </div>

        <p className="plant-count">Showing {filteredPlants.length} of {plants.length} plants</p>
        {renderPlantCards()}
      </section>
    )
  }

  function renderCareScheduler() {
    return (
      <section className="panel page-panel">
        <div className="section-heading">
          <div><span className="eyebrow">PLANT CARE ROUTINE</span><h2>Care Scheduler</h2><p>Plan watering and other care activities.</p></div>
          <button className="primary-btn" onClick={() => {
            setTaskForm({ ...emptyTask, plant: plants[0]?.name || '' })
            setShowTaskForm(true)
          }}>+ Add Task</button>
        </div>

        <div className="stats-grid">
          <div className="stat-card"><div><span>Pending Tasks</span><h3>{pendingTasks.length}</h3></div></div>
          <div className="stat-card"><div><span>Completed Tasks</span><h3>{completedTasks.length}</h3></div></div>
          <div className="stat-card"><div><span>Overdue Tasks</span><h3>{overdueTasks.length}</h3></div></div>
        </div>

        {renderTaskRows()}
      </section>
    )
  }

  function renderGrowthAnalytics() {
    const chartData = [...growthRecords]
      .sort((a, b) => new Date(a.date) - new Date(b.date))
      .map((record) => ({
        ...record,
        chartLabel: `${record.plant} · ${record.date}`,
      }))

    return (
      <section className="panel page-panel">
        <div className="section-heading">
          <div><span className="eyebrow">GROWTH TRACKER</span><h2>Growth Analytics</h2><p>Record plant heights and monitor development.</p></div>
          <button className="primary-btn" onClick={() => {
            setGrowthForm({ ...emptyGrowth, plant: plants[0]?.name || '' })
            setShowGrowthForm(true)
          }}>+ Add Growth Record</button>
        </div>

        <div className="stats-grid">
          <div className="stat-card"><div><span>Total Records</span><h3>{growthRecords.length}</h3></div></div>
          <div className="stat-card"><div><span>Plants Tracked</span><h3>{plantsTracked}</h3></div></div>
        </div>

        {!growthRecords.length ? (
          <div className="empty-state"><span>📈</span><h3>Your growth story starts here</h3><p>Add a plant measurement to start tracking growth.</p></div>
        ) : (
          <>
            <div className="chart-container">
              <ResponsiveContainer width="100%" height={320}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="chartLabel" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="height" name="Plant Height (cm)" stroke="#4f8b55" strokeWidth={3} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {growthRecords.map((record) => (
              <div className="growth-record-item" key={record.id}>
                <div className="growth-record-details">
                  <h4>{record.plant}</h4><p>{record.date}</p>
                  {record.notes && <p>{record.notes}</p>}
                </div>
                <strong>{record.height} cm</strong>
                <button className="delete-btn" onClick={() => deleteGrowthRecord(record.id)}>🗑️</button>
              </div>
            ))}
          </>
        )}
      </section>
    )
  }

  function renderHealthJournal() {
    return (
      <section className="panel page-panel">
        <div className="section-heading">
          <div><span className="eyebrow">PLANT WELLNESS</span><h2>Health Journal</h2><p>Record plant observations and treatments.</p></div>
          <button className="primary-btn" onClick={() => {
            setHealthForm({ ...emptyHealth, plant: plants[0]?.name || '' })
            setShowHealthForm(true)
          }}>+ Add Observation</button>
        </div>

        {!healthRecords.length ? (
          <div className="empty-state"><span>🩺</span><h3>Your health journal is empty</h3><p>Add your first plant health observation.</p></div>
        ) : healthRecords.map((record) => (
          <div className="journal-card" key={record.id}>
            <div className="journal-card-top">
              <div className="journal-icon">🌿</div>
              <div className="journal-title"><h3>{record.plant}</h3><span>{record.date}</span></div>
              <span className="health-status">{record.status}</span>
              <button className="delete-btn" onClick={() => deleteHealthRecord(record.id)}>🗑️</button>
            </div>
            <div className="journal-card-content">
              <h4>Observation</h4><p>{record.observation}</p>
              {record.treatment && <><h4>Treatment / Action</h4><p>{record.treatment}</p></>}
            </div>
          </div>
        ))}
      </section>
    )
  }

  function renderPageContent() {
    if (activePage === 'Dashboard') return renderDashboard()
    if (activePage === 'My Plants') return renderMyPlants()
    if (activePage === 'Care Scheduler') return renderCareScheduler()
    if (activePage === 'Growth Analytics') return renderGrowthAnalytics()
    if (activePage === 'Health Journal') return renderHealthJournal()
    return null
  }

  // REUSABLE PLANT SELECT FIELD
  function PlantSelect({ value, onChange }) {
    return (
      <select value={value} onChange={onChange} required>
        <option value="">Choose a plant</option>
        {plants.map((plant) => (
          <option key={plant.id} value={plant.name}>{plant.name}</option>
        ))}
      </select>
    )
  }

  function renderModal(title, close, content) {
    return (
      <div className="modal-overlay" onClick={close}>
        <div className="modal-card" onClick={(event) => event.stopPropagation()}>
          <div className="modal-header">
            <h2>{title}</h2>
            <button type="button" className="modal-close" onClick={close}>×</button>
          </div>
          {content}
        </div>
      </div>
    )
  }

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon">🌿</div>
          <div><h1>GreenNest</h1><p>Grow with care</p></div>
        </div>

        <div className="sidebar-section-label">MENU</div>
        <nav className="sidebar-nav">
          {[
            { name: 'Dashboard', icon: '⌂' },
            { name: 'My Plants', icon: '🪴' },
            { name: 'Care Scheduler', icon: '🗓️' },
            { name: 'Growth Analytics', icon: '📈' },
            { name: 'Health Journal', icon: '🩺' },
          ].map((item) => (
            <button
              key={item.name}
              className={`nav-item ${activePage === item.name ? 'active' : ''}`}
              onClick={() => openPage(item.name)}
            >
              <span className="nav-icon">{item.icon}</span>
              <span>{item.name}</span>
              {item.name === 'Care Scheduler' && pendingTasks.length > 0 &&
                <span className="nav-badge">{pendingTasks.length}</span>}
            </button>
          ))}
        </nav>

        <div className="sidebar-tip">
          <div className="tip-icon">☀️</div>
          <h3>A little care goes a long way!</h3>
          <p>Healthy plants make a happy home. Remember to check your plants every day.</p>
        </div>

        <div className="sidebar-profile">
          <div className="profile-avatar">🌱</div>
          <div className="profile-details"><h4>Plant Parent</h4><p>Home Gardener</p></div>
          <span className="profile-menu">•••</span>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div className="topbar-title">
            <p className="breadcrumb">GreenNest / {activePage}</p>
            <h2>{activePage}</h2>
          </div>
          <div className="topbar-actions">
            <div className="welcome-message"><span>Welcome back!</span><span className="welcome-emoji">🌿</span></div>
            <button className="primary-btn" onClick={openAddPlant}>+ Add Plant</button>
          </div>
        </header>

        <div className="page-content">
          {loading && <p>Loading your garden from MongoDB...</p>}
          {error && (
            <div role="alert" style={{ color: '#b91c1c', background: '#fff0f0', padding: 12, borderRadius: 8, marginBottom: 12 }}>
              {error}
              <button className="text-btn" onClick={loadAll}>Retry</button>
            </div>
          )}
          {notice && <p role="status" style={{ color: '#237847' }}>{notice}</p>}
          {!loading && renderPageContent()}
        </div>

        <footer className="app-footer">
          <p>© {new Date().getFullYear()} GreenNest — Growing happiness, one plant at a time.</p>
        </footer>
      </main>

      {/* ADD / EDIT PLANT MODAL */}
      {showPlantForm && renderModal(
        editingPlantId ? 'Edit Plant Details' : 'Add a New Plant',
        () => setShowPlantForm(false),
        <form className="modal-form" onSubmit={savePlant}>
          <label>Plant Name
            <input value={plantForm.name} onChange={(e) => setPlantForm({ ...plantForm, name: e.target.value })} required />
          </label>
          <label>Plant Type
            <input value={plantForm.type} onChange={(e) => setPlantForm({ ...plantForm, type: e.target.value })} required />
          </label>
          <label>Location
            <input value={plantForm.location} onChange={(e) => setPlantForm({ ...plantForm, location: e.target.value })} required />
          </label>
          <label>Watering Frequency
            <select value={plantForm.watering} onChange={(e) => setPlantForm({ ...plantForm, watering: e.target.value })}>
              <option>Daily</option><option>Every 2 days</option><option>Twice a week</option><option>Weekly</option><option>Every 2 weeks</option>
            </select>
          </label>
          <label>Sunlight Requirement
            <select value={plantForm.sunlight} onChange={(e) => setPlantForm({ ...plantForm, sunlight: e.target.value })}>
              <option>Low light</option><option>Indirect sunlight</option><option>Bright indirect light</option><option>Direct sunlight</option>
            </select>
          </label>
          <label>Plant Icon
            <select value={plantForm.emoji} onChange={(e) => setPlantForm({ ...plantForm, emoji: e.target.value })}>
              <option value="🪴">🪴 Potted Plant</option><option value="🌿">🌿 Green Leaves</option><option value="🌵">🌵 Cactus</option><option value="🌱">🌱 Seedling</option><option value="🌸">🌸 Flower</option><option value="🌻">🌻 Sunflower</option>
            </select>
          </label>
          <label>Health Status
            <select value={plantForm.status} onChange={(e) => setPlantForm({ ...plantForm, status: e.target.value })}>
              <option>Healthy</option><option>Needs Attention</option><option>Under Treatment</option>
            </select>
          </label>
          <div className="modal-actions">
            <button type="button" className="secondary-btn" onClick={() => setShowPlantForm(false)}>Cancel</button>
            <button type="submit" className="primary-btn">{editingPlantId ? 'Save Changes' : 'Add Plant'}</button>
          </div>
        </form>
      )}

      {/* CARE TASK MODAL */}
      {showTaskForm && renderModal(
        'Add a Care Task',
        () => setShowTaskForm(false),
        <form className="modal-form" onSubmit={addTask}>
          <label>Task Title
            <input value={taskForm.title} onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })} placeholder="e.g. Water Money Plant" required />
          </label>
          <label>Select Plant
            <PlantSelect value={taskForm.plant} onChange={(e) => setTaskForm({ ...taskForm, plant: e.target.value })} />
          </label>
          <label>Care Type
            <select value={taskForm.type} onChange={(e) => setTaskForm({ ...taskForm, type: e.target.value })}>
              <option>Watering</option><option>Fertilizing</option><option>Pruning</option><option>Sunlight</option><option>Repotting</option><option>Inspection</option><option>Other</option>
            </select>
          </label>
          <label>Due Date
            <input type="date" value={taskForm.date} onChange={(e) => setTaskForm({ ...taskForm, date: e.target.value })} required />
          </label>
          <div className="modal-actions">
            <button type="button" className="secondary-btn" onClick={() => setShowTaskForm(false)}>Cancel</button>
            <button type="submit" className="primary-btn">Save Task</button>
          </div>
        </form>
      )}

      {/* GROWTH RECORD MODAL */}
      {showGrowthForm && renderModal(
        'Add Growth Record',
        () => setShowGrowthForm(false),
        <form className="modal-form" onSubmit={addGrowthRecord}>
          <label>Select Plant
            <PlantSelect value={growthForm.plant} onChange={(e) => setGrowthForm({ ...growthForm, plant: e.target.value })} />
          </label>
          <label>Plant Height (cm)
            <input type="number" min="0.1" step="0.1" value={growthForm.height} onChange={(e) => setGrowthForm({ ...growthForm, height: e.target.value })} required />
          </label>
          <label>Record Date
            <input type="date" value={growthForm.date} onChange={(e) => setGrowthForm({ ...growthForm, date: e.target.value })} required />
          </label>
          <label>Observation
            <textarea rows="3" value={growthForm.notes} onChange={(e) => setGrowthForm({ ...growthForm, notes: e.target.value })} />
          </label>
          <div className="modal-actions">
            <button type="button" className="secondary-btn" onClick={() => setShowGrowthForm(false)}>Cancel</button>
            <button type="submit" className="primary-btn">Save Growth Record</button>
          </div>
        </form>
      )}

      {/* HEALTH JOURNAL MODAL */}
      {showHealthForm && renderModal(
        'Add Health Observation',
        () => setShowHealthForm(false),
        <form className="modal-form" onSubmit={addHealthRecord}>
          <label>Select Plant
            <PlantSelect value={healthForm.plant} onChange={(e) => setHealthForm({ ...healthForm, plant: e.target.value })} />
          </label>
          <label>Observation Date
            <input type="date" value={healthForm.date} onChange={(e) => setHealthForm({ ...healthForm, date: e.target.value })} required />
          </label>
          <label>Plant Health Status
            <select value={healthForm.status} onChange={(e) => setHealthForm({ ...healthForm, status: e.target.value })}>
              <option>Healthy</option><option>Needs Attention</option><option>Under Treatment</option>
            </select>
          </label>
          <label>Observation
            <textarea rows="3" value={healthForm.observation} onChange={(e) => setHealthForm({ ...healthForm, observation: e.target.value })} required />
          </label>
          <label>Treatment / Action
            <textarea rows="3" value={healthForm.treatment} onChange={(e) => setHealthForm({ ...healthForm, treatment: e.target.value })} />
          </label>
          <div className="modal-actions">
            <button type="button" className="secondary-btn" onClick={() => setShowHealthForm(false)}>Cancel</button>
            <button type="submit" className="primary-btn">Save Observation</button>
          </div>
        </form>
      )}
    </div>
  )
}

export default App

